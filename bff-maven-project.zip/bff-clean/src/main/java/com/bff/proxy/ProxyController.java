package com.bff.proxy;

import com.bff.oauth2.TokenRefreshManager;
import com.bff.properties.BffProperties;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.CurrentSecurityContext;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClient;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Collections;
import java.util.Set;
import java.util.UUID;

/**
 * Reverse proxy controller — replaces Spring Cloud Gateway entirely.
 *
 * Every request to /api/** is:
 *   1. Authenticated (enforced by SecurityConfig)
 *   2. Token refreshed proactively if expiring (via TokenRefreshManager)
 *   3. Enriched with the valid Bearer token from the encrypted cookie
 *   4. Forwarded to the backend via RestClient (Spring 6 synchronous HTTP client)
 *   5. The backend response is returned to the browser
 *
 * No Mono, no WebFlux, no reactive types — plain synchronous Java.
 *
 * ─── Responsibility boundary ──────────────────────────────────────────────────
 *
 *  ✅  This controller does:
 *       • Strip dangerous inbound headers (Cookie, Authorization, X-Internal-*)
 *       • Proactively refresh the access token if near expiry
 *       • Inject the Bearer token from the server-side cookie
 *       • Add tracing headers (X-Correlation-ID, X-Forwarded-*)
 *       • Strip implementation-leaking response headers (Server, X-Powered-By)
 *
 *  ❌  This controller does NOT:
 *       • Validate the JWT signature
 *       • Verify iss / aud / scope / roles claims
 *       • Make authorization decisions based on token content
 *       → All of the above are exclusively the backend's responsibility.
 */
@Slf4j
@RestController
public class ProxyController {

    /**
     * Headers from the browser that must NEVER be forwarded to the backend.
     * Prevents clients from spoofing identity or bypassing backend security.
     */
    private static final Set<String> BLOCKED_REQUEST_HEADERS = Set.of(
            "cookie",            // never forward BFF cookies to the backend
            "authorization",     // we inject our own refreshed Bearer token
            "x-internal-user",   // internal trust header – must not be forgeable
            "x-internal-role",   // internal trust header – must not be forgeable
            "x-real-ip",         // we set this from the actual connection
            "host"               // must reflect the backend host, not the BFF host
    );

    /**
     * Headers from the backend response that must NOT be returned to the browser.
     * Prevents technology stack fingerprinting.
     */
    private static final Set<String> BLOCKED_RESPONSE_HEADERS = Set.of(
            "server",
            "x-powered-by",
            "x-application-context",
            "transfer-encoding"  // handled by the Servlet container
    );

    private final RestClient           restClient;
    private final BffProperties        props;
    private final TokenRefreshManager  tokenRefreshManager;

    public ProxyController(BffProperties props,
                           RestClient.Builder restClientBuilder,
                           TokenRefreshManager tokenRefreshManager) {
        this.props              = props;
        this.tokenRefreshManager = tokenRefreshManager;
        this.restClient = restClientBuilder
                .baseUrl(props.proxy().backendUrl())
                .build();
    }

    /**
     * Proxies all /api/** requests to the backend.
     */
    @RequestMapping("/api/**")
    public ResponseEntity<byte[]> proxy(
            HttpServletRequest request,
            HttpServletResponse response,
            @RequestBody(required = false) byte[] body,
            @CurrentSecurityContext(expression = "authentication") Authentication authentication) {

        String backendPath = request.getRequestURI();
        String query       = request.getQueryString();

        // ── 1. Build backend URI ──────────────────────────────────────────────
        URI backendUri = UriComponentsBuilder
                .fromUriString(props.proxy().backendUrl())
                .path(backendPath)
                .query(query)
                .build(true)
                .toUri();

        // ── 2. Strip dangerous inbound headers ────────────────────────────────
        HttpHeaders forwardHeaders = buildForwardHeaders(request);

        // ── 3. Resolve access token — refresh proactively if near expiry ──────
        //
        //  TokenRefreshManager checks the expiresAt timestamp stored in the
        //  encrypted cookie. If the token is expired or expiring within 30 s:
        //    → calls the IdP token endpoint with the refresh_token
        //    → writes the new token into the BFF_TOKEN cookie
        //    → returns the fresh token value
        //
        //  This is a timestamp check, NOT a JWT signature validation.
        //  The backend always validates the signature — the BFF never does.
        String accessToken = tokenRefreshManager.resolveAccessToken(
                authentication, request, response);

        if (accessToken == null) {
            log.warn("No access token available for principal '{}' – returning 401",
                    authentication != null ? authentication.getName() : "unknown");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("{\"error\":\"no_token\"}".getBytes());
        }

        forwardHeaders.setBearerAuth(accessToken);

        // ── 4. Add tracing headers ────────────────────────────────────────────
        forwardHeaders.set("X-Correlation-ID",  UUID.randomUUID().toString());
        forwardHeaders.set("X-BFF-Version",     "1");
        forwardHeaders.set("X-Forwarded-For",   request.getRemoteAddr());
        forwardHeaders.set("X-Forwarded-Host",  request.getServerName());
        forwardHeaders.set("X-Forwarded-Port",  String.valueOf(request.getServerPort()));
        forwardHeaders.set("X-Forwarded-Proto", request.getScheme());

        // ── 5. Forward to backend ─────────────────────────────────────────────
        try {
            HttpMethod method = HttpMethod.valueOf(request.getMethod());

            ResponseEntity<byte[]> backendResponse = restClient
                    .method(method)
                    .uri(backendUri)
                    .headers(h -> h.addAll(forwardHeaders))
                    .body(body != null ? body : new byte[0])
                    .retrieve()
                    .toEntity(byte[].class);

            // ── 6. Strip implementation-leaking response headers ───────────────
            HttpHeaders cleanHeaders = stripBlockedResponseHeaders(
                    backendResponse.getHeaders());

            return ResponseEntity
                    .status(backendResponse.getStatusCode())
                    .headers(cleanHeaders)
                    .body(backendResponse.getBody());

        } catch (HttpStatusCodeException ex) {
            return ResponseEntity
                    .status(ex.getStatusCode())
                    .body(ex.getResponseBodyAsByteArray());

        } catch (Exception ex) {
            log.error("Proxy error forwarding {} {}: {}",
                    request.getMethod(), backendPath, ex.getMessage());
            return ResponseEntity
                    .status(HttpStatus.BAD_GATEWAY)
                    .body("{\"error\":\"backend_unavailable\"}".getBytes());
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private HttpHeaders buildForwardHeaders(HttpServletRequest request) {
        HttpHeaders headers = new HttpHeaders();
        Collections.list(request.getHeaderNames()).forEach(name -> {
            if (!BLOCKED_REQUEST_HEADERS.contains(name.toLowerCase())) {
                headers.set(name, request.getHeader(name));
            }
        });
        return headers;
    }

    private HttpHeaders stripBlockedResponseHeaders(HttpHeaders original) {
        HttpHeaders clean = new HttpHeaders();
        original.forEach((name, values) -> {
            if (!BLOCKED_RESPONSE_HEADERS.contains(name.toLowerCase())) {
                clean.put(name, values);
            }
        });
        return clean;
    }
}
