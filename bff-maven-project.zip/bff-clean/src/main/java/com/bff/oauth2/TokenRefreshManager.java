package com.bff.oauth2;

import com.bff.properties.BffProperties;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.OAuth2AuthorizeRequest;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProviderBuilder;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.DefaultOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;

/**
 * Proactively refreshes expired (or near-expiry) OAuth2 access tokens
 * before the BFF forwards a request to the backend.
 *
 * ─── Responsibility boundary ──────────────────────────────────────────────────
 *
 *  ✅  BFF does:    Check the token's expiresAt timestamp (a local, free operation)
 *                   Call the IdP token endpoint with the refresh_token if needed
 *                   Write the fresh token back into the encrypted BFF_TOKEN cookie
 *
 *  ❌  BFF does NOT: Validate the JWT signature
 *                   Verify the iss / aud / scope claims
 *                   Call the JWKS endpoint
 *                   Make revocation decisions
 *
 *  All of the above are exclusively the backend's responsibility.
 *
 * ─── Why proactive refresh instead of reactive? ───────────────────────────────
 *
 *  Option A – Reactive (bad): forward the expired token, get 401 from backend,
 *             then refresh and retry. This means every expiry causes a failed
 *             request, a retry, and two backend round-trips.
 *
 *  Option B – Proactive (good): check expiresAt before forwarding. If the token
 *             is expired or expiring within the REFRESH_BUFFER window, refresh it
 *             first. The backend always receives a valid token on the first attempt.
 *
 * ─── REFRESH_BUFFER ──────────────────────────────────────────────────────────
 *
 *  We refresh the token if it expires within the next 30 seconds. This prevents
 *  the race condition where the token is valid when the BFF checks but expires
 *  by the time the backend validates it (network latency + clock skew).
 */
@Slf4j
@Component
public class TokenRefreshManager {

    /**
     * Refresh the token if it expires within this window.
     * Accounts for network latency between BFF and backend, and minor clock skew
     * between the BFF server and the IdP.
     */
    private static final Duration REFRESH_BUFFER = Duration.ofSeconds(30);

    private final OAuth2AuthorizedClientManager      authorizedClientManager;
    private final CookieOAuth2AuthorizedClientRepository cookieRepository;
    private final BffProperties                      props;
    private final Clock                              clock;

    public TokenRefreshManager(
            ClientRegistrationRepository clientRegistrationRepository,
            CookieOAuth2AuthorizedClientRepository cookieRepository,
            BffProperties props) {
        this.cookieRepository       = cookieRepository;
        this.props                  = props;
        this.clock                  = Clock.systemUTC();
        this.authorizedClientManager = buildAuthorizedClientManager(
                clientRegistrationRepository, cookieRepository);
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Returns a valid access token for the authenticated principal.
     *
     * If the current token is still valid, returns it immediately (no I/O).
     * If the token is expired or expiring within REFRESH_BUFFER, calls the IdP
     * token endpoint to get a fresh one, updates the BFF_TOKEN cookie, and
     * returns the new token value.
     *
     * @param authentication the current Spring Security principal
     * @param request        the current HTTP request (needed to read the cookie)
     * @param response       the current HTTP response (needed to write the refreshed cookie)
     * @return the access token string to use in the Authorization: Bearer header,
     *         or null if no token is available (caller should return 401)
     */
    public String resolveAccessToken(Authentication authentication,
                                      HttpServletRequest request,
                                      HttpServletResponse response) {
        if (authentication == null) return null;

        String registrationId = props.oauth2().registrationId();

        // ── Load the current authorized client from the cookie ─────────────────
        OAuth2AuthorizedClient client = cookieRepository.loadAuthorizedClient(
                registrationId, authentication, request);

        if (client == null || client.getAccessToken() == null) {
            log.warn("No OAuth2AuthorizedClient found for principal '{}' – session may have expired",
                    authentication.getName());
            return null;
        }

        // ── Fast path: token is still valid ───────────────────────────────────
        if (!isExpiredOrExpiringSoon(client.getAccessToken())) {
            log.debug("Access token is valid for principal '{}', forwarding as-is",
                    authentication.getName());
            return client.getAccessToken().getTokenValue();
        }

        // ── Slow path: token is expired or expiring soon ──────────────────────
        if (client.getRefreshToken() == null) {
            // No refresh token available (IdP did not issue one, or it was not stored).
            // Return the current token and let the backend decide what to do.
            log.warn("Access token for '{}' is expiring but no refresh token is available – " +
                     "forwarding expired token, backend will return 401",
                    authentication.getName());
            return client.getAccessToken().getTokenValue();
        }

        log.info("Access token for '{}' expires at {} – refreshing proactively",
                authentication.getName(), client.getAccessToken().getExpiresAt());

        return refreshAndReturnToken(authentication, request, response, registrationId);
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    /**
     * Calls the IdP token endpoint to exchange the refresh_token for a new
     * access_token. Saves the result back into the BFF_TOKEN cookie.
     *
     * @return the new access token value, or the old one if refresh failed
     */
    private String refreshAndReturnToken(Authentication authentication,
                                          HttpServletRequest request,
                                          HttpServletResponse response,
                                          String registrationId) {
        try {
            // OAuth2AuthorizeRequest triggers the refresh_token grant when the
            // access token is expired and a refresh token is available.
            OAuth2AuthorizeRequest authorizeRequest = OAuth2AuthorizeRequest
                    .withClientRegistrationId(registrationId)
                    .principal(authentication)
                    .attribute(HttpServletRequest.class.getName(),  request)
                    .attribute(HttpServletResponse.class.getName(), response)
                    .build();

            // This call goes to the IdP token endpoint (synchronous HTTP call).
            // On success, it returns an OAuth2AuthorizedClient with a new access token.
            // The manager automatically saves the updated client via our cookieRepository,
            // which writes the refreshed token into the BFF_TOKEN cookie.
            OAuth2AuthorizedClient refreshedClient =
                    authorizedClientManager.authorize(authorizeRequest);

            if (refreshedClient != null && refreshedClient.getAccessToken() != null) {
                log.info("Successfully refreshed access token for principal '{}'",
                        authentication.getName());
                return refreshedClient.getAccessToken().getTokenValue();
            }

        } catch (Exception ex) {
            // Refresh failed: IdP is down, refresh token is revoked, etc.
            // Log the failure but do not crash the request — forward the
            // expired token and let the backend return 401 to the browser.
            log.error("Token refresh failed for principal '{}': {}",
                    authentication.getName(), ex.getMessage());
        }

        // Fallback: return the current (expired) token.
        // The backend will return 401, which will propagate to the browser,
        // which will trigger a new login via the React bffClient interceptor.
        OAuth2AuthorizedClient fallbackClient = cookieRepository.loadAuthorizedClient(
                registrationId, authentication, request);
        return fallbackClient != null && fallbackClient.getAccessToken() != null
                ? fallbackClient.getAccessToken().getTokenValue()
                : null;
    }

    /**
     * Returns true if the access token is already expired or will expire
     * within the REFRESH_BUFFER window.
     *
     * Checking expiresAt is a local, free operation — no cryptography, no I/O.
     * This is NOT token validation: we are not verifying the signature or claims.
     * We are simply asking "should we bother asking the IdP for a new one?"
     */
    private boolean isExpiredOrExpiringSoon(OAuth2AccessToken accessToken) {
        Instant expiresAt = accessToken.getExpiresAt();
        if (expiresAt == null) {
            // No expiry information — assume valid
            return false;
        }
        Instant refreshThreshold = Instant.now(clock).plus(REFRESH_BUFFER);
        return expiresAt.isBefore(refreshThreshold);
    }

    /**
     * Builds the OAuth2AuthorizedClientManager configured with:
     *   • authorization_code  – used at login
     *   • refresh_token       – used for proactive token refresh
     *
     * The manager uses our CookieOAuth2AuthorizedClientRepository so that
     * refreshed tokens are written back into the encrypted BFF_TOKEN cookie.
     */
    private OAuth2AuthorizedClientManager buildAuthorizedClientManager(
            ClientRegistrationRepository clientRegistrationRepository,
            CookieOAuth2AuthorizedClientRepository cookieRepository) {

        DefaultOAuth2AuthorizedClientManager manager =
                new DefaultOAuth2AuthorizedClientManager(
                        clientRegistrationRepository,
                        cookieRepository);

        manager.setAuthorizedClientProvider(
                OAuth2AuthorizedClientProviderBuilder.builder()
                        .authorizationCode()   // handles the initial login flow
                        .refreshToken()        // handles proactive refresh
                        .build()
        );

        return manager;
    }
}
