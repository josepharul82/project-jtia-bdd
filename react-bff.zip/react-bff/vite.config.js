import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],

  // Allow @/ as an alias for src/
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
    },
  },

  server: {
    port: 5000,

    // Proxy /api and /bff calls to the BFF during development.
    // This avoids CORS issues: the browser talks to :5000 (Vite),
    // which forwards to :9090 (BFF) transparently.
    //
    // With this proxy you can simplify bffClient.js to use relative paths
    // (e.g. '/api/v1/projets') instead of 'http://localhost:9090/api/v1/projets'.
    proxy: {
      '/api':          { target: 'http://localhost:9090', changeOrigin: true },
      '/bff':          { target: 'http://localhost:9090', changeOrigin: true },
      '/oauth2':       { target: 'http://localhost:9090', changeOrigin: true },
      '/login':        { target: 'http://localhost:9090', changeOrigin: true },
      '/logout':       { target: 'http://localhost:9090', changeOrigin: true },
    },
  },
});
