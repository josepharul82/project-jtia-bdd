/**
 * src/pages/ProjetsPage.jsx
 *
 * Full CRUD example for /api/v1/projets.
 * Demonstrates GET, POST, PUT, DELETE using bffClient helpers.
 */

import { useState } from 'react';
import { useFetch } from '../hooks/useFetch';
import { bffPost, bffPut, bffDelete } from '../api/bffClient';
import Spinner from '../components/Spinner';

export default function ProjetsPage() {
  const { data: projets, loading, error, refetch } = useFetch('/api/v1/projets');

  const [form,    setForm]    = useState({ name: '', description: '' });
  const [editing, setEditing] = useState(null); // { id, name, description }
  const [saving,  setSaving]  = useState(false);
  const [formErr, setFormErr] = useState(null);

  // ── Create ─────────────────────────────────────────────────────────────────
  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    setFormErr(null);
    try {
      await bffPost('/api/v1/projets', form);
      setForm({ name: '', description: '' });
      refetch();
    } catch (err) {
      setFormErr(err.message);
    } finally {
      setSaving(false);
    }
  }

  // ── Update ─────────────────────────────────────────────────────────────────
  async function handleUpdate(e) {
    e.preventDefault();
    setSaving(true);
    setFormErr(null);
    try {
      await bffPut(`/api/v1/projets/${editing.id}`, editing);
      setEditing(null);
      refetch();
    } catch (err) {
      setFormErr(err.message);
    } finally {
      setSaving(false);
    }
  }

  // ── Delete ─────────────────────────────────────────────────────────────────
  async function handleDelete(id) {
    if (!window.confirm('Supprimer ce projet ?')) return;
    try {
      await bffDelete(`/api/v1/projets/${id}`);
      refetch();
    } catch (err) {
      alert(err.message);
    }
  }

  return (
    <main className="page">
      <h1 className="page__title">Projets</h1>

      {/* ── Create / Edit form ──────────────────────────────────────────── */}
      <div className="card">
        <h2 className="card__title">{editing ? 'Modifier le projet' : 'Nouveau projet'}</h2>

        <form onSubmit={editing ? handleUpdate : handleCreate} className="form">
          <div className="form__group">
            <label className="form__label">Nom</label>
            <input
              className="form__input"
              type="text"
              required
              value={editing ? editing.name : form.name}
              onChange={(e) =>
                editing
                  ? setEditing({ ...editing, name: e.target.value })
                  : setForm({ ...form, name: e.target.value })
              }
            />
          </div>

          <div className="form__group">
            <label className="form__label">Description</label>
            <input
              className="form__input"
              type="text"
              value={editing ? editing.description : form.description}
              onChange={(e) =>
                editing
                  ? setEditing({ ...editing, description: e.target.value })
                  : setForm({ ...form, description: e.target.value })
              }
            />
          </div>

          {formErr && <p className="form__error">{formErr}</p>}

          <div className="form__actions">
            <button className="btn btn--primary" type="submit" disabled={saving}>
              {saving ? 'Enregistrement…' : editing ? 'Mettre à jour' : 'Créer'}
            </button>
            {editing && (
              <button className="btn btn--outline" type="button" onClick={() => setEditing(null)}>
                Annuler
              </button>
            )}
          </div>
        </form>
      </div>

      {/* ── List ────────────────────────────────────────────────────────── */}
      <div className="card">
        <h2 className="card__title">Liste des projets</h2>

        {loading && <Spinner />}
        {error   && <p className="text-error">Erreur : {error}</p>}

        {!loading && !error && projets?.length === 0 && (
          <p className="text-muted">Aucun projet pour l'instant.</p>
        )}

        {!loading && !error && projets?.length > 0 && (
          <table className="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Description</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {projets.map((p) => (
                <tr key={p.id}>
                  <td>{p.id}</td>
                  <td>{p.name}</td>
                  <td>{p.description || '—'}</td>
                  <td className="table__actions">
                    <button
                      className="btn btn--sm btn--outline"
                      onClick={() => setEditing({ id: p.id, name: p.name, description: p.description ?? '' })}
                    >
                      Modifier
                    </button>
                    <button
                      className="btn btn--sm btn--danger"
                      onClick={() => handleDelete(p.id)}
                    >
                      Supprimer
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </main>
  );
}
