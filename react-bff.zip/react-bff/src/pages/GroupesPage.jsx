/**
 * src/pages/GroupesPage.jsx
 *
 * Example page for /api/v1/projetGroups — demonstrates the useFetch hook
 * with a simpler read-only + delete list.
 */

import { useState } from 'react';
import { useFetch } from '../hooks/useFetch';
import { bffPost, bffDelete } from '../api/bffClient';
import Spinner from '../components/Spinner';

export default function GroupesPage() {
  const { data: groupes, loading, error, refetch } = useFetch('/api/v1/projetGroups');
  const [name,   setName]   = useState('');
  const [saving, setSaving] = useState(false);
  const [formErr,setFormErr]= useState(null);

  async function handleCreate(e) {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true);
    setFormErr(null);
    try {
      await bffPost('/api/v1/projetGroups', { name });
      setName('');
      refetch();
    } catch (err) {
      setFormErr(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm('Supprimer ce groupe ?')) return;
    try {
      await bffDelete(`/api/v1/projetGroups/${id}`);
      refetch();
    } catch (err) {
      alert(err.message);
    }
  }

  return (
    <main className="page">
      <h1 className="page__title">Groupes de projets</h1>

      {/* ── Create form ─────────────────────────────────────────────────── */}
      <div className="card">
        <h2 className="card__title">Nouveau groupe</h2>
        <form onSubmit={handleCreate} className="form form--inline">
          <input
            className="form__input"
            type="text"
            placeholder="Nom du groupe"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <button className="btn btn--primary" type="submit" disabled={saving}>
            {saving ? 'Création…' : 'Créer'}
          </button>
        </form>
        {formErr && <p className="form__error">{formErr}</p>}
      </div>

      {/* ── List ────────────────────────────────────────────────────────── */}
      <div className="card">
        <h2 className="card__title">Groupes existants</h2>

        {loading && <Spinner />}
        {error   && <p className="text-error">Erreur : {error}</p>}

        {!loading && !error && groupes?.length === 0 && (
          <p className="text-muted">Aucun groupe pour l'instant.</p>
        )}

        {!loading && !error && groupes?.length > 0 && (
          <ul className="item-list">
            {groupes.map((g) => (
              <li key={g.id} className="item-list__row">
                <span>{g.name}</span>
                <button
                  className="btn btn--sm btn--danger"
                  onClick={() => handleDelete(g.id)}
                >
                  Supprimer
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  );
}
