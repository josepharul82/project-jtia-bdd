/**
 * src/pages/HomePage.jsx
 * Landing page — shows the authenticated user's profile.
 */

import { useUser } from '../components/AuthGuard';

export default function HomePage() {
  const { user } = useUser();

  return (
    <main className="page">
      <div className="card">
        <h1 className="page__title">Bonjour, {user.given_name || user.name} 👋</h1>
        <p className="page__subtitle">Vous êtes connecté via Keycloak.</p>

        <div className="profile-grid">
          <ProfileRow label="Identifiant"  value={user.sub} />
          <ProfileRow label="Nom complet"  value={user.name} />
          <ProfileRow label="Prénom"       value={user.given_name} />
          <ProfileRow label="Nom"          value={user.family_name} />
          <ProfileRow label="Email"        value={user.email} />
        </div>
      </div>
    </main>
  );
}

function ProfileRow({ label, value }) {
  return (
    <div className="profile-row">
      <span className="profile-row__label">{label}</span>
      <span className="profile-row__value">{value || '—'}</span>
    </div>
  );
}
