/**
 * src/hooks/useFetch.js
 *
 * Generic hook for fetching data from the BFF.
 * Handles loading, error, and abort-on-unmount automatically.
 *
 * Usage:
 *   const { data, loading, error, refetch } = useFetch('/api/v1/projets');
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { bffFetch } from '../api/bffClient';

export function useFetch(path, options = {}) {
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);

  // Keep a ref to an AbortController so we can cancel on unmount
  const abortRef = useRef(null);

  const fetchData = useCallback(() => {
    // Cancel any previous in-flight request
    if (abortRef.current) abortRef.current.abort();
    abortRef.current = new AbortController();

    setLoading(true);
    setError(null);

    bffFetch(path, { ...options, signal: abortRef.current.signal })
      .then((result) => {
        setData(result);
        setLoading(false);
      })
      .catch((err) => {
        if (err.name === 'AbortError' || err.status === 408) return; // cancelled
        setError(err.message ?? 'Unknown error');
        setLoading(false);
      });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path]);

  useEffect(() => {
    fetchData();
    return () => { if (abortRef.current) abortRef.current.abort(); };
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
}
