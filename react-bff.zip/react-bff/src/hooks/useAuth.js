/**
 * src/hooks/useAuth.js
 *
 * Single source of truth for authentication state.
 * Calls GET /bff/user on mount to verify the current BFF session.
 *
 * Returns:
 *   user    – OIDC profile { sub, name, given_name, family_name, email } or null
 *   loading – true while the session check is in flight
 *   logout  – function that calls POST /logout and redirects to /
 */

import { useState, useEffect, useCallback } from 'react';
import { bffFetch, bffPost } from '../api/bffClient';

export function useAuth() {
  const [user,    setUser]    = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    bffFetch('/bff/user')
      .then((data) => setUser(data))
      .catch((err) => {
        // 401 is handled by bffFetch (auto-redirect to IdP login).
        // We only land here for unexpected errors (BFF down, network failure).
        if (err.status !== 401) {
          console.error('[useAuth] unexpected error:', err.message);
        }
        setUser(null);
      })
      .finally(() => setLoading(false));
  }, []);

  /**
   * POST /logout — Spring Security clears the BFF_TOKEN cookie, then calls
   * Keycloak's end_session_endpoint (RP-Initiated Logout) to invalidate the
   * SSO session. After that we redirect to / to start fresh.
   *
   * Never use <a href="/logout"> — Spring Security only accepts POST /logout.
   */
  const logout = useCallback(() => {
    bffPost('/logout', null)
      .catch(() => { /* ignore errors during logout */ })
      .finally(() => { window.location.href = '/'; });
  }, []);

  return { user, loading, logout };
}
