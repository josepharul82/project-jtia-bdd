/**
 * src/components/Navbar.jsx
 *
 * Top navigation bar. Reads the authenticated user from UserContext
 * and exposes a logout button.
 *
 * Usage:
 *   // Must be inside <AuthGuard>
 *   <Navbar />
 */

import { Link, useLocation } from 'react-router-dom';
import { useUser } from './AuthGuard';

export default function Navbar() {
  const { user, logout } = useUser();
  const location = useLocation();

  const isActive = (path) =>
    location.pathname === path ? 'nav-link nav-link--active' : 'nav-link';

  return (
    <header className="navbar">
      <div className="navbar__brand">
        <span className="navbar__logo">🛡️</span>
        <span className="navbar__title">Mon Application</span>
      </div>

      <nav className="navbar__links">
        <Link to="/"         className={isActive('/')}>Accueil</Link>
        <Link to="/projets"  className={isActive('/projets')}>Projets</Link>
        <Link to="/groupes"  className={isActive('/groupes')}>Groupes</Link>
      </nav>

      <div className="navbar__user">
        <span className="navbar__user-name">
          👤 {user.given_name || user.name || user.email}
        </span>
        <button className="btn btn--outline btn--sm" onClick={logout}>
          Déconnexion
        </button>
      </div>
    </header>
  );
}
