/**
 * src/components/AuthGuard.jsx
 *
 * Wraps any subtree that requires an authenticated session.
 *
 *  1. Calls GET /bff/user on mount (via useAuth)
 *  2. Shows a spinner while the check is in flight
 *  3. If unauthenticated → bffClient redirects to IdP automatically
 *  4. If authenticated   → renders children and provides { user, logout }
 *     via UserContext so any descendant can call useUser()
 *
 * Usage:
 *   <AuthGuard>
 *     <YourProtectedApp />
 *   </AuthGuard>
 *
 *   // In any child:
 *   const { user, logout } = useUser();
 */

import React, { createContext, useContext } from 'react';
import { useAuth } from '../hooks/useAuth';
import Spinner from './Spinner';

// ─── Context ──────────────────────────────────────────────────────────────────

const UserContext = createContext(null);

export function useUser() {
  const ctx = useContext(UserContext);
  if (!ctx) throw new Error('useUser() must be called inside <AuthGuard>');
  return ctx;
}

// ─── AuthGuard ────────────────────────────────────────────────────────────────

export function AuthGuard({ children }) {
  const { user, loading, logout } = useAuth();

  if (loading) {
    return (
      <div className="auth-guard-loading">
        <Spinner />
        <p>Vérification de la session…</p>
      </div>
    );
  }

  // If user is null, bffClient has already initiated window.location.href redirect.
  // Render nothing to avoid a flash of content before the redirect completes.
  if (!user) return null;

  return (
    <UserContext.Provider value={{ user, logout }}>
      {children}
    </UserContext.Provider>
  );
}
