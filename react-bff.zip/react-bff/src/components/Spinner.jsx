/**
 * src/components/Spinner.jsx
 * Simple CSS spinner — no external dependencies.
 */

export default function Spinner({ size = 32 }) {
  return (
    <div
      className="spinner"
      style={{ width: size, height: size }}
      aria-label="Chargement…"
      role="status"
    />
  );
}
