/**
 * src/App.jsx
 *
 * Application root.
 *
 * AuthGuard wraps the entire router:
 *   • Calls GET /bff/user on mount to verify the session
 *   • If not authenticated → bffClient redirects to the IdP automatically
 *   • If authenticated     → renders the app and provides { user, logout } via context
 */

import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthGuard } from './components/AuthGuard';
import Navbar      from './components/Navbar';
import HomePage    from './pages/HomePage';
import ProjetsPage from './pages/ProjetsPage';
import GroupesPage from './pages/GroupesPage';

export default function App() {
  return (
    <AuthGuard>
      {/* Navbar is inside AuthGuard so useUser() works */}
      <Navbar />

      <Routes>
        <Route path="/"         element={<HomePage />} />
        <Route path="/projets"  element={<ProjetsPage />} />
        <Route path="/groupes"  element={<GroupesPage />} />

        {/* Catch-all: redirect unknown paths to home */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AuthGuard>
  );
}
