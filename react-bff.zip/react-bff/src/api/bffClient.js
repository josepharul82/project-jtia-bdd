/**
 * src/api/bffClient.js
 *
 * Thin fetch wrapper for all BFF calls. No external dependencies — native fetch only.
 *
 * What it handles automatically:
 *
 *  1. BASE URL
 *     Reads VITE_BFF_BASE_URL from the environment.
 *     Empty string (default) means the Vite proxy handles routing to :9090.
 *     In production, set VITE_BFF_BASE_URL if React and BFF are on different origins.
 *
 *  2. SESSION COOKIE  (credentials: 'include')
 *     BFF_TOKEN is an HttpOnly cookie — JS cannot read it, but the browser sends
 *     it automatically when credentials: 'include' is set.
 *
 *  3. CSRF TOKEN  (X-XSRF-TOKEN header)
 *     The BFF writes a readable XSRF-TOKEN cookie. Spring Security requires it
 *     back as X-XSRF-TOKEN on POST / PUT / PATCH / DELETE.
 *
 *  4. SESSION EXPIRY  (401 → redirect to IdP)
 *     When BFF_TOKEN expires the BFF returns 401 + { loginUrl }.
 *     bffFetch catches this, redirects to the IdP, and returns a never-resolving
 *     promise so no component error state fires during the redirect.
 *
 *  5. JSON parsing
 *     Parses and returns JSON bodies directly. Returns the raw Response for
 *     other content types (blobs, plain text, etc.).
 */

// ─── Config ───────────────────────────────────────────────────────────────────

// Empty string = use Vite proxy (recommended in dev).
// Set VITE_BFF_BASE_URL=https://bff.example.com for cross-origin production deployments.
const BFF_BASE_URL = import.meta.env.VITE_BFF_BASE_URL ?? '';
const TIMEOUT_MS   = 30_000;

// ─── Utility ──────────────────────────────────────────────────────────────────

/** Reads a browser cookie by name. Returns null if absent. */
function getCookie(name) {
  const match = document.cookie.match(
    new RegExp('(?:^|; )' + name.replace(/([.*+?^=!:${}()|[\]/\\])/g, '\\$1') + '=([^;]*)')
  );
  return match ? decodeURIComponent(match[1]) : null;
}

/** Returns true for HTTP methods that mutate state and require a CSRF token. */
function requiresCsrf(method = 'GET') {
  return ['POST', 'PUT', 'PATCH', 'DELETE'].includes(method.toUpperCase());
}

/** Merge two AbortSignals — aborts when either fires. */
function anySignal(signals) {
  const controller = new AbortController();
  for (const signal of signals) {
    if (signal.aborted) { controller.abort(); break; }
    signal.addEventListener('abort', () => controller.abort(), { once: true });
  }
  return controller.signal;
}

// ─── Custom error class ───────────────────────────────────────────────────────

export class BffError extends Error {
  constructor(message, status) {
    super(message);
    this.name   = 'BffError';
    this.status = status;
  }
}

// ─── Core fetch wrapper ───────────────────────────────────────────────────────

/**
 * Core BFF fetch function. Use the convenience helpers below for everyday calls.
 *
 * @param {string}      path    - Path relative to the BFF, e.g. '/api/v1/projets'
 * @param {RequestInit} options - Standard fetch options (method, body, headers, …)
 * @returns {Promise<any>}       - Parsed JSON body, or raw Response for non-JSON
 */
export async function bffFetch(path, options = {}) {
  const { method = 'GET', headers = {}, body, signal, ...rest } = options;

  // ── Build headers ──────────────────────────────────────────────────────────
  const mergedHeaders = {
    'Content-Type': 'application/json',
    'Accept':       'application/json',
    ...headers,
  };

  if (requiresCsrf(method)) {
    const csrfToken = getCookie('XSRF-TOKEN');
    if (csrfToken) mergedHeaders['X-XSRF-TOKEN'] = csrfToken;
  }

  // ── Timeout ────────────────────────────────────────────────────────────────
  const controller  = new AbortController();
  const timeoutId   = setTimeout(() => controller.abort(), TIMEOUT_MS);
  const mergedSignal = signal ? anySignal([signal, controller.signal]) : controller.signal;

  // ── Execute ────────────────────────────────────────────────────────────────
  let response;
  try {
    response = await fetch(`${BFF_BASE_URL}${path}`, {
      method,
      credentials: 'include', // REQUIRED: sends BFF_TOKEN + XSRF-TOKEN cookies
      headers:     mergedHeaders,
      body,
      signal:      mergedSignal,
      ...rest,
    });
  } catch (err) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') throw new BffError('Request timed out', 408);
    throw new BffError(`Network error: ${err.message}`, 0);
  } finally {
    clearTimeout(timeoutId);
  }

  // ── 401: session expired → redirect to IdP ─────────────────────────────────
  if (response.status === 401) {
    let loginUrl = '/oauth2/authorization/keycloak';
    try {
      const data = await response.json();
      if (data?.loginUrl) loginUrl = data.loginUrl;
    } catch { /* ignore */ }

    window.location.href = loginUrl;
    return new Promise(() => {}); // never resolves — page is redirecting
  }

  // ── Non-2xx errors ─────────────────────────────────────────────────────────
  if (!response.ok) {
    let message = `HTTP ${response.status} ${response.statusText}`;
    try {
      const err = await response.json();
      if (err?.message) message = err.message;
      else if (err?.error) message = err.error;
    } catch { /* ignore */ }
    throw new BffError(message, response.status);
  }

  // ── Parse response ─────────────────────────────────────────────────────────
  const contentType = response.headers.get('Content-Type') ?? '';
  if (contentType.includes('application/json')) return response.json();
  return response; // caller handles .blob(), .text(), etc.
}

// ─── Convenience helpers ──────────────────────────────────────────────────────

export const bffGet = (path, options = {}) =>
  bffFetch(path, { ...options, method: 'GET' });

export const bffPost = (path, body, options = {}) =>
  bffFetch(path, { ...options, method: 'POST', body: body != null ? JSON.stringify(body) : undefined });

export const bffPut = (path, body, options = {}) =>
  bffFetch(path, { ...options, method: 'PUT', body: JSON.stringify(body) });

export const bffPatch = (path, body, options = {}) =>
  bffFetch(path, { ...options, method: 'PATCH', body: JSON.stringify(body) });

export const bffDelete = (path, options = {}) =>
  bffFetch(path, { ...options, method: 'DELETE' });
