# react-bff

React SPA (Vite) connectée au BFF Spring Boot via OAuth2 / Keycloak.

## Stack

| Élément | Version |
|---|---|
| React | 18 |
| React Router | 6 |
| Vite | 5 |
| Build | JS + JSX (pas de TypeScript) |

## Structure

```
src/
├── api/
│   └── bffClient.js          ← fetch wrapper (cookie, CSRF, 401, timeout)
├── hooks/
│   ├── useAuth.js            ← vérification session + logout
│   └── useFetch.js           ← hook générique de chargement de données
├── components/
│   ├── AuthGuard.jsx         ← protège l'app, fournit UserContext
│   ├── Navbar.jsx            ← navigation + badge utilisateur
│   └── Spinner.jsx           ← indicateur de chargement
├── pages/
│   ├── HomePage.jsx          ← profil utilisateur
│   ├── ProjetsPage.jsx       ← CRUD projets (/api/v1/projets)
│   └── GroupesPage.jsx       ← CRUD groupes (/api/v1/projetGroups)
├── styles/
│   └── index.css             ← styles globaux (pas de CSS-in-JS)
├── App.jsx                   ← routes + AuthGuard
└── main.jsx                  ← point d'entrée React
```

## Démarrage rapide

### Prérequis
- Node.js ≥ 18
- BFF Spring Boot en cours d'exécution sur `http://localhost:9090`
- Keycloak en cours d'exécution sur `http://localhost:8180`

### Installation

```bash
npm install
```

### Développement

```bash
npm run dev
# → http://localhost:5000
```

Le proxy Vite (`vite.config.js`) redirige automatiquement `/api`, `/bff`, `/oauth2`, `/login`, `/logout` vers le BFF sur `:9090`.

### Production

```bash
npm run build
# → dist/
```

Servez le dossier `dist/` depuis n'importe quel serveur statique ou CDN.
Configurez `VITE_BFF_BASE_URL` si le frontend et le BFF sont sur des origines différentes.

## Variables d'environnement

| Variable | Dev | Prod |
|---|---|---|
| `VITE_BFF_BASE_URL` | `""` (proxy Vite) | `""` ou `https://bff.exemple.com` |

## Fonctionnement de l'authentification

1. L'utilisateur ouvre `http://localhost:5000`
2. `AuthGuard` appelle `GET /bff/user`
3. Si non authentifié → le BFF retourne `401 { loginUrl }` → redirection vers Keycloak
4. Après login → Keycloak redirige vers le BFF → le BFF écrit le cookie `BFF_TOKEN` (chiffré HttpOnly)
5. Le BFF redirige vers l'URL initiale → `AuthGuard` recharge → session confirmée
6. Toutes les requêtes `/api/**` envoient automatiquement le cookie `BFF_TOKEN` et le header `X-XSRF-TOKEN`
